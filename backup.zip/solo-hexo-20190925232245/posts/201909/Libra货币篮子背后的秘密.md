title: Libra货币篮子背后的秘密
date: '2019-09-22 21:15:25'
updated: '2019-09-22 21:15:25'
tags: [资讯]
permalink: /articles/2019/09/22/1569158125654.html
---
专题：Libra的货币篮子背后是经济、金融和政治因素妥协后的产物。当前透露出的Libra实际货币篮子与我们的预言基本相合。美元在Libra中居于主导地位，欧元、日元和英磅都在货币篮子里，唯一超预期的地方在于，新加坡元被纳入到Libra的货币篮子。

新加坡元被纳入到Libra，是符合Libra的战略目标的，中国作为全球经济举足轻重的大国，其影响力不容Libra忽视，新加坡元与人民币的正相关性较强，新加坡元可看作人民币的影子。USD在Libra锚定的一篮子货币中占比达50%，除了美元本身的实力之外，可能也与政治因素的考量有关。Libra的货币篮子有新加坡元而没有人民币，美元占比达50%的背后，是经济、金融和政治因素妥协后的产物。

行情：

BTC反弹受阻，其余主流通证反弹较大。本周数字通证总市值为2743.2亿美元，上升3.9%；日均成交量为574.2亿美元，上升10.1%；日均换手率为21.0%，上升1.6%。BTC现价10181美元，跌幅为1.7%；本周BTC日均成交量为153亿美元，日均换手率为8.3%。ETH现价218.1美元，涨幅为20.4%；本周ETH日均成交量为84亿美元，日均换手率为38.0%。本周交易所BTC余额为87.50万个，增加0.51万个；交易所ETH余额为939万个，增加17万个。BICS二级行业中，支支付结算市值有所降低，公共服务通证数量增长明显。

产出与热度：

挖矿难度和算力显著上升，ETH关注度有所回升。BTC本周挖矿难度为11.89T，较上周上升0.932TT，本周日均算力为91.70EH/s，较上周上升2.77EH/s；ETH本周挖矿难度2425，较上周上升105，日均算力190.0TH/S，较上周上升9.5TH/S。

行业：

区块链应用范围逐渐扩展，引起普遍重视。加拿大区块链公司将为石油天然气财团开发区块链解决方案；委内瑞拉公建房将使用石油币交付；Bitwise向SEC提交报告称市场已经准备好推出ETF ；土耳其公布国家区块链基础设施计划。

风险提示：监管政策风险、市场趋势风险

## 正文

1专题：Libra货币篮子是经济、金融和政治因素妥协后的产物

据报道，Facebook在回复德国立法委员De Masi的信中公布了Libra货币篮子的具体构成，其中美元50%，欧元18%，日元14%，英镑11%，新加坡元7%。

[![微信图片_20190922122934](https://img.bishijie.com/156912815957591.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

1.1 Libra货币篮子的构成基本符合我们的预期

我们在《多种货币/资产抵押的Libra会更加“稳定”吗？——Libra运行机制猜想》中预言，Libra的货币篮子构成为：美元47.68%、欧元35.00%、日元11.02%、英镑6.30%。

当前透露出的Libra实际货币篮子与我们的预言基本相合。美元在Libra中居于主导地位，欧元、日元和英磅都在货币篮子里，唯一超预期的地方在于，新加坡元被纳入到Libra的货币篮子。

[![微信图片_20190922122845](https://img.bishijie.com/156912816091028.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

1.2 作为人民币影子的新加坡元？

新加坡元被纳入到Libra，是符合Libra的战略目标的，新加坡元可看作人民币的影子。新加坡央行对区块链技术非常开放包容，另外中国是新加坡最大的贸易伙伴，新加坡元与人民币的正相关性较强，据外媒统计，在调查的12种货币中，新加坡元与人民币的正相关性最强。将新加坡元纳入到货币篮子，可看作间接将人民币纳入Libra的货币篮子。

Libra的目标是成为一种集稳定性、低通货膨胀率、全球普遍接受和可互换性这些最佳货币特征于一体的稳定数字通证。根据Libra白皮书对其稳定机制和储备资产的描述，Libra基于多种货币计价的低波动资产抵押物的结构，与国际货币基金组织（IMF）的SDR非常类似，具备一定“超主权”货币的属性。

根据国际货币基金组织SDR货币构成的变迁可知，“超主权”货币需要具备卓越的国际影响力与较高的可自由使用度，此外，优良的主权信用、适中的通货膨胀率及较低波动率也是必不可少的条件。

[![微信图片_20190922122941](https://img.bishijie.com/156912816013679.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

在此前的报告《多种货币/资产抵押的Libra会更加“稳定”吗？——Libra运行机制猜想》中，我们认为参考SDR篮子选择货币标准的经验，美元、欧元、英镑和日元大概率会首先入选Libra货币篮子，入选货币的主权国家必须具备较高的信用等级、雄厚的经济实力、货币本身具备市场深度和使用的广泛性。

Libra通过新加坡元间接将人民币纳入篮子的原因在于，人民币在国际市场上的深度和流通性还存在一定的不足。然而Libra要提高自己的吸引力，其货币篮子像SDR一样，要反映篮子货币在全球贸易和金融体系中的重要性程度。

中国作为全球经济举足轻重的大国，其影响力不容Libra忽视。

1.3 Libra的货币篮子是经济、金融和政治因素妥协的产物

我们能够精准的预言Libra一篮子货币的构成，并不是我们有“水晶球”，而是我们洞悉Libra的战略目标、条件和约束，Libra的货币篮子是经济、金融和政治因素妥协的产物。

美国时间7月17日的Libra众议院听证会上，密苏里州众议员安·瓦格纳 (Ann Wagner) 询问Facebook如何在不损害美元地位或破坏全球经济稳定的情况下推出一种全球货币，Libra项目负责人David Marcus回答称Libra最初的储备或有一半以上是美元，另一半是稳定的主权货币和低风险资产，所以对美元的影响较小，并表示在解决所有的监管问题之前，将不会推出Libra。

USD在Libra锚定的一篮子货币中占比达50%，除了美元本身的实力之外，可能也与政治因素的考量有关。Facebook发行Libra，虽说是私企的独立行为，但以Facebook的体量、美国政府部门和全球市场的高度关注，很难说Libra仅仅是一个互联网企业的一次创新。美国很有可能在数字货币和支付领域再次引领创新，抢滩取得数字货币霸权，建立数字边疆壁垒。Libra的货币篮子有新加坡元而没有人民币，美元占比达50%的背后，是经济、金融和政治因素妥协后的产物。

2行情：BTC反弹受阻，其余主流通证反弹较大

2.1 整体行情：主流通证反弹较大

本周数字通证总市值为2743.2亿美元，相比上周增加59亿美元，涨幅约3.9%。延续上周震荡上行的走势。

数字通证市场日均成交量为574.2亿美元，较上周上升10.1%，日均换手率为21.0%，较上周上升1.6%。

[![微信图片_20190922122945](https://img.bishijie.com/156912816145751.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

  

[![微信图片_20190922122948](https://img.bishijie.com/156912816125160.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

本周交易所BTC余额为87.50万个，较上周增加0.51万个。交易所ETH余额为939万个，较上周增加17万个。交易所BTC及ETH余额不同幅度上升，场内抛压加重。

[![微信图片_20190922122951](https://img.bishijie.com/156912816125168.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)[![微信图片_20190922122954](https://img.bishijie.com/156912816216355.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

USDT市值为41.1亿美元，较上周增加1448万美元。目前资金进场热情有所回落，USDT溢价程度较低，仅有微小溢价。

[![微信图片_20190922122958](https://img.bishijie.com/156912816383640.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)[![微信图片_20190922123002](https://img.bishijie.com/156912816374926.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

2.2 核心通证：ETH领涨主流通证

BTC现价10181美元，周跌幅为1.7%，月涨幅为0.4%。本周BTC日均成交量为153亿美元，日均换手率为8.3%。BTC本周震荡下行，表现弱于主流通证。

[![微信图片_20190922123006](https://img.bishijie.com/156912816385401.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

ETH现价218.1美元，周涨幅为20.4%，月涨幅为16.7%。本周ETH日均成交量为84亿美元，日均换手率38.0%。ETH本周领涨主流通证。

[![微信图片_20190922123010](https://img.bishijie.com/156912816417780.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

EOS现价4.01美元，周涨幅7.7%，月涨幅14.6%。本周EOS日均成交量为21亿美元，日均换手率54.5%。EOS本周迎来较大涨幅。

[![微信图片_20190922123012](https://img.bishijie.com/156912816473611.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

XRP现价0.29美元，周涨幅为15.2%，月涨幅为10.6%。本周XRP日均成交量为16亿美元，日均换手率12.8%。

[![微信图片_20190922123043](https://img.bishijie.com/156912816517749.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

本周多数主要通证的月波动率上行，BTC月波动率为10.7%，较上周下降3.1%；ETH月波动率为15.1%，较上周持平；EOS月波动率为18.2%，较上周上涨0.3%；XRP月波动率为16.0%，较上周上涨5.0%。本周市场BTC波动率有所下降，ETH无变化，其他主流通证波动率上行。

[![微信图片_20190922123046](https://img.bishijie.com/156912816566180.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

2.3 BICS行业：支付结算市值有所降低，公共服务通证数量增长明显

在市值排名前五位的BICS（Blockchain Industry Classification Standard，区块链行业分类标准）二级行业中，支付结算行业市值有所降低，从76.0%降至73.7%。从市值占比变化率看，性能优化行业市值占比增速较高，相比上周分别增长了30.0%；实物资产类市值占比下降较为明显，较上周分别下降了19.0%。

[![微信图片_20190922123049](https://img.bishijie.com/156912816627790.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)[![微信图片_20190922123054](https://img.bishijie.com/156912816661501.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

本周通证数量增长较为明显的BICS二级行业为公共服务、医疗保健和信息技术，相比上周分别增长了14.3%、12.5%和11.4%；本周通证数量下降较为明显的BICS二级行业分别为通证资管、通信服务和操作平台，相比上周分别下降了7.7%、5.6%和5.5%。

[![微信图片_20190922123056](https://img.bishijie.com/156912816656347.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)[![微信图片_20190922123059](https://img.bishijie.com/156912816765576.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

2.4 市场观点：市场蠢蠢欲动

本周BTC表现弱于主流通证，部分主流通证率先开始反弹，EOS、ETH、XRP纷等主流通证纷纷迎来较大反弹。

市场蠢蠢欲动，大行情或即将到来。本周BTC表现较为疲软，部分主力转移至其他主流通证，EOS、ETH、XRP纷纷迎来较大反弹，打破了僵持多日的震荡局面。

3产出与热度：挖矿难度和算力显著上升

挖矿难度及算力显著上升。BTC本周挖矿难度为11.89T，较上周上升0.932T，本周日均算力为91.70EH/s，较上周上升2.77EH/s；ETH本周挖矿难度2425，较上周上升105，日均算力190.0TH/S，较上周上升9.5TH/S。

[![微信图片_20190922123102](https://img.bishijie.com/156912816761044.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)[![微信图片_20190922123104](https://img.bishijie.com/156912816833235.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

本周，Google Trends统计的Bitcoin词条搜索热度为9，同上周持平，Ethereum词条搜索热度为8，较上周有所回升。

[![微信图片_20190922123106](https://img.bishijie.com/156912816885129.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)[![微信图片_20190922123109](https://img.bishijie.com/156912816972379.jpg?imageView2/0/format/jpg/q/75)](https://www.bishijie.com/static/app/web/img/shendu-pic-lazyload.png)

4行业要闻：区块链应用范围逐渐扩展，引起普遍重视

4.1 加拿大区块链公司将为石油天然气财团开发区块链解决方案

据BTCMANAGER消息，离岸运营商委员会（OOC）石油和天然气区块链联盟与加拿大GuildOne区块链公司合作，GuildOne将为联盟支出授权(AFE)投票开发概念验证区块链解决方案，目的是降低贸易摩擦和提高成本效益。据悉，OOC石油和天然气区块链联盟是由七大石油和天然气公司在美国建立的第一个行业区块链财团，其成员包括雪佛龙公司，康菲石油公司，埃克森美孚公司，Equinor公司和荷兰皇家壳牌公司等。

4.2 委内瑞拉公建房将使用石油币交付

据The Daily Hodl 9月19日消息，Bitwise向美国证券交易委员会提交了一份报告，称过去两年的三个关键变化“显著改善”了比特币市场，即比特币现货市场变得高效、比特币监管已经完全成为机构、受监管的期货市场变得重要。报告称数据显示，目前美国有一个健全的基础，可以建立一个受到全面监管的比特币ETF。

4.3 Bitwise向SEC提交报告称市场已经准备好推出ETF

据Argaam 9月11日消息，沙特阿拉伯货币局（SAMA）负责银行业务的副行长Hisham Al Hogail表示，沙特阿拉伯和阿联酋将在年底前完成跨境银行交易数字通证的试点工作。试点工作可能将重点放在技术方面，同时，法律和经济方面将在稍后阶段进行审查。2019年1月，SAMA和阿联酋央行（UAECB）联合推出了Aber，这是一个旨在促进两国跨境结算的数字通证项目。

4.4 土耳其公布国家区块链基础设施计划

据Cointelegraph 9月18日消息，土耳其工业和技术部在《2023年战略》中公布了“国家区块链基础设施”的计划，即建立一个全国性的区块链基础设施，在公共管理中使用分布式账本技术。《2023年战略》强调区块链和DLT是明年国家技术行动的重点。
