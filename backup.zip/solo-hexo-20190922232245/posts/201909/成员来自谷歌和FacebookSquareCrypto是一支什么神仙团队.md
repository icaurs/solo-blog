title: 成员来自谷歌和Facebook，Square Crypto是一支什么神仙团队？
date: '2019-09-21 10:29:39'
updated: '2019-09-21 10:29:39'
tags: [资讯]
permalink: /articles/2019/09/21/1569032979403.html
---
Square Crypto今天在推特上宣布，该公司请了三名新的软件工程师。**Square Crypto是支付公司Square的加密货币部门，Square由推特创始人兼首席执行官Jack Dorsey创立。**

这些工程师分别来自Lightning Labs、谷歌和Facebook主导的稳定币网络Libra：

Valentine Wallace来自Lightning Labs，Jeffrey Czyz来自谷歌，Arik Sozman来自Facebook，他为Facebook的区块链项目Libra开发了Calibra钱包。

上个月，Square Crypto宣布聘请了Blockstream的联合创始人、比特币核心开发者Matt Corallo。前谷歌主管Steve Lee则在今年6月成为了Square Crypto的一号员工。

这个团队可以说是开发者里面的明星团队，小编为大家找到了每位成员的资料：

![2](https://cdn.8btc.com/wp-content/uploads/2019/09/201909201126598788.png)

**Valentine Wallace**是一位美女开发者，毕业于加州大学伯克利分校。她在网上的公开信息较少，领英资料一直停留在2017年8月，当时她是微软的实习工程师。她的个人简介是“对Bitcoin Core和闪电网络开发很感兴趣，拒绝2X（Segwit2x）、拒绝Coinbase，HODL。”看来这个曾就职于闪电网络开发团队Lightning Labs的小姐姐是不折不扣的比特币支持者，难怪她会选择加入Square Crypto。

![3](https://cdn.8btc.com/wp-content/uploads/2019/09/201909201127508938.png)

从实习生到软件工程师，**Jeffrey Czyz**在谷歌埋头干了10年。2013年就开始用推特的他，到了现在居然只发了4条推文，看来的确是醉心于软件开发。别人发推特，他在搞开发，别人在看剧，他还在搞开发。相信Czyz将会成为Square Crypto的骨干力量。

![4](https://cdn.8btc.com/wp-content/uploads/2019/09/201909201128194337.png)

**Arik Sozman**的神奇之处在于领英上完全找不到他的资料。曾是Facebook一员的他居然也没有Facebook账号，但在推特上很活跃。但他的推文全是在各种转发文章啊，转发的内容大概是创业、比特币、区块链、以太坊，有点像朋友圈里的爸妈，只不过他转发的不是养生文章。但能参与Calibra开发，就足以证明他的实力了。

![5](https://cdn.8btc.com/wp-content/uploads/2019/09/201909201128333030.png)

**Matt Corallo**是Blockstream的联合创始人以及Chaincode Labs的工程师，这两家公司都致力于比特币开发。Corallo本人活跃于比特币社区，同时是个低调的实干家。神奇的是，他也在谷歌当过实习生。

![6](https://cdn.8btc.com/wp-content/uploads/2019/09/201909201128493030.png)

（来自产品经理的“假笑”？）

与前几位不同的是，**Steve Lee**是一个产品经理，程序员的天敌。他在谷歌当了近10年的产品经理，从去年3月开始入圈，他同时还是天使投资人。

总结来看，Square Crypto是一个集结了各路大牛但却十分低调的团队。

正如Dorsey今年3月所说的那样，这些工程师将成为比特币和加密货币生态系统的全职开发者，为其作出开源贡献。

Square crypto的目标是改善比特币生态系统。具体是以什么样的形式呢？还不知道。但根据今天的声明，无论这个团队最终会做什么，其都将是一个“改进或普及比特币”的项目。

![1](https://cdn.8btc.com/wp-content/uploads/2019/09/201909201129246871.png)

> “下一步是决定我们的第一个项目。本着开源的精神，我们想要听听你们的意见。只要能改进或普及比特币的项目我们都会考虑。”

但这个团队不太可能创造另一种加密货币；本月早些时候，Dorsey在接受采访时表示，比特币仍然是互联网原生货币的“最佳选择”，而不是商业替代品。

Square Crypto是在今年3月成立的新部门，直接向Dorsey汇报，且该团队成员可以选择是否以比特币的形式支付工资。

当时，Dorsey表示：

**“Square向开源社区索取了太多，才走到了今天，但我们并未作出太多回报。这是我们一个小小的回馈方式，也是一种符合所有人利益的做法：一个面向互联网的更开放的全球金融体系。”**  

>
