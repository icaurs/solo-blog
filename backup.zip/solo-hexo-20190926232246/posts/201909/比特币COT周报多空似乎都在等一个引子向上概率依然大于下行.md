title: 【比特币COT周报】多空似乎都在等一个“引子”，向上概率依然大于下行
date: '2019-09-21 10:13:33'
updated: '2019-09-21 10:13:33'
tags: [狂人看币]
permalink: /articles/2019/09/21/1569032012965.html
---
**一周行情回顾**

比特币本周的k线似乎又走出了一个类十字星的形态，最高价10355美元，最低价9631美元，周振幅7.52%，周跌幅1.38%。周四盘中急速下跌5%，跌破10000美元大关，但在周五凌晨又急速拉回到10000美元上方，这显示了比特币目前下方的支撑依然较强，只是多头发动向上的攻击的意愿也不是很强烈，市场中的资金依旧在观望。截止至9月21日早上8时，比特币在火币交易所报价10172美元。  

**持仓状况**

本周CME的比特币期货非商业持仓（投机账户）多空双方开始加仓，但空头加仓速度更快。多头仓位环比增加55手，空头仓位环比增加174手，净持仓仍表现为空头，较上周净空头持仓增加119手。商业持仓中，多头持仓依然为0，空头仓位相较上周没有变化依然是26手。预示着散户持仓水平的非可报告持仓表现为净多头，较前一周净持仓水平上涨12.1%。

![1.png](https://img.bishijie.com/156902522417166.png?imageView2/0/format/png/q/75)

![null](https://img.bishijie.com/156902522588054.gif?imageView2/0/format/gif/q/75)

本周未平持仓量（持仓兴趣）相比上周增加46手，目前持仓量4174手。

![2.png](https://img.bishijie.com/156902522595337.png?imageView2/0/format/png/q/75)

![null](https://img.bishijie.com/156902522588054.gif?imageView2/0/format/gif/q/75)

从分类账户看，本周卖方（Dealer）账户的多、空双方持仓均未有变化，净持仓依然保持空头；大型投资基金（Asset Manger）的多头仓位较上周增加18手，空头仓位增加11手，总体依然保持净多头持仓且数量微幅增加；Leverage Fund账户净空头的持仓相比上周增加25手，增幅4.6%；Other Reportable 账户本周净空头仓位小幅增加，相比上周增加101手。

![null](https://img.bishijie.com/156902522683063.png?imageView2/0/format/png/q/75)

![null](https://img.bishijie.com/156902522675478.png?imageView2/0/format/png/q/75)

![null](https://img.bishijie.com/156902522732885.png?imageView2/0/format/png/q/75)

![null](https://img.bishijie.com/156902522839797.png?imageView2/0/format/png/q/75)

![null](https://img.bishijie.com/156902522588054.gif?imageView2/0/format/gif/q/75)

**持仓状况简评：**

1.大型投资基金（Asset Manager）多空双方小幅加仓，多头增加数量略大，整体净多头的数量也较上周小幅增加。这也只是说明多头势力微微增加。

2. 卖方（Dealer）账户本周没有变化，依然暗示市场中多头势力略微占优。

3. 上周空头大幅减仓的其他类（Other Reportable）账户本周的空头微微增加，但对整体影响不大。

4. 综合而言，本周持仓结构较上周变化不大。对市场影响最重的两个账户（Dealer和Asset Manager）都指向多头市场，继续维持上周的判断：多空双方目前都在观望，向上的概率大于下行，配置上应倾向于多头策略。

![7.png](https://img.bishijie.com/156902522859814.png?imageView2/0/format/png/q/75)![null](https://img.bishijie.com/156902522588054.gif?imageView2/0/format/gif/q/75)

*注：以上的市场判断基于芝商所COT持仓报告，仅供投资者交流学习，并不构成任何投资建议。
